from datetime import datetime
class Transactions:
    def __init__(self,book,user,action):
        self.book=book
        self.user=user
        self.action=action
        self.date=datetime.now()
        
# Display transaction details
    def display_transaction(self):
        print(f"User: {self.user.name}, Book: {self.book.title}, Action: {self.action}, Date: {self.date}")

      
 