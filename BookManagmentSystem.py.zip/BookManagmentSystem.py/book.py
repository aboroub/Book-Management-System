
# Book 
class Book:
# craet constructer and add attribute

    def __init__(self,title,author,isbn,copies):
        
        self.title=title
        self.author=author
        self.isbn=isbn
        self.copies=copies
        self.borrowed_copies=0
# creat Function for borrowing process

    def borrow(self):
        if self.copies>self.borrowed_copies:
            self.borrowed_copies +=1
            return True
        else:
            print("There are no copies available to borrow.")

# return Book

    def return_Book(self):
        if self.borrowed_copies>0:
            self.borrowed_copies -=1
            return True
        else:
            return False
        
# Show information

    def display_details(self):
        print(f"Title:{self.title},Author:{self.author},ISBN:{self.isbn},Copies{self.copies},Borrow:{self.borrowed_copies}")