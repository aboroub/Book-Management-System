# main page 
# First, we call up the classes that we use in the program from their files.


from book import Book
from transaction import Transactions 
from library import Library
from user import Admin, RegularUser

def main():
    # Create a library
    my_library = Library()

    # Create books
    book1 = Book(title="1998", author="George Orwell", isbn=1234567890, copies=5)
    book2 = Book(title="The Match", author="Harlen Coben", isbn=1234543566, copies=3) 

    # Add books to the library
    my_library.add_book(book1)
    my_library.add_book(book2)

    # Display books
    my_library.display_books()

    # Create User and Admin
    admin = Admin(user_id=1, name="mahmoud")
    user = RegularUser(user_id=2, name="Tariq")

    # Print details of Admin
    print("Admin Details:")
    admin.display_details()

    # Borrow a book 
    user.borrow_book(book1)
    user.display_details()

    # Return a book
    user.return_book(book1)
    user.display_details()

    # Record a transaction
    transaction = Transactions(user=user, book=book1, action="borrow")
    transaction.display_transaction()

    print(f"User object: {user}")
    print(f"User borrowed books: {user.borrowed_books}")

if __name__ == "__main__":
    main()



