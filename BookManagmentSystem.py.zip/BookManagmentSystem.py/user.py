# creat class for user
class User:
    def __init__(self,user_id,name,role):
        self.user_id=user_id
        self.name=name
        self.role=role
        self.borrowed_books=[]
        self.fines=0
# borrow processing 

    def borrow_book(self,book):     
        if book.borrow():
            self.borrowed_books.append(book)
            print(f"{self.name} borrow {book.title}")
        else:
            print(f"No copies of {book.title}")

# return books
    def return_book(self,book):
        if book.return_Book():
            self.borrowed_books.remove(book)
        else:
            print("This book has not been borrowed by the user")
# display information 
    def display_details(self):
       borrowed_titles = [book.title for book in self.borrowed_books]
       print(f"User ID: {self.user_id}, Name: {self.name}, Role: {self.role}, Borrowed Books: {borrowed_titles}, Fine Amount: {self.fines}")

# The Admin class is inherited from the User class
class Admin(User):
    def __init__(self, user_id, name):
        super().__init__(user_id, name, role='Admin')

# Additional admin tasks can be added here

    def add_book(self, library, book):
        library.add_book(book)

    def remove_book(self, library, isbn):
        library.remove_book(isbn)

# The RegularUser class is inherited from the User class
class RegularUser(User):
    def __init__(self, user_id, name):
        super().__init__(user_id, name, role='Regular')

            
