from book  import Book 
class Library:
 def __init__(self):
        self.books = {}

 def add_book(self, book):
    if book.isbn in self.books:
        print("The book alredy exists")
    else:
        self.books[book.isbn] = book

 def remove_book(self, isbn):
        if isbn in self.books:
            del self.books[isbn]
        else:
            print("The book does not exist.")
    
 def display_books(self):
        
        for book in self.books.values():
            book.display_details()




